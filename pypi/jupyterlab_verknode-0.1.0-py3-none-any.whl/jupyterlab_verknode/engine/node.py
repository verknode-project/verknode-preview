"""Node model API: ports, dialog fields, execution context and the node registry.

Port indices: index 0 is the implicit flow variable port that
every node has (the red "mickey mouse ears"), explicit ports start at 1.
"""
from __future__ import annotations

import contextlib
import copy
import os
from dataclasses import dataclass

import polars as pl

from .flowvars import FlowVariable, make

TABLE = "table"
FLOWVARIABLE = "flowvariable"
MODEL = "model"  # trained model (blue square port)
IMAGE = "image"  # rendered image (green square port)
DB_SESSION = "dbsession"  # database connection (dark red square port)
DB_DATA = "dbdata"  # database connection + SQL query (brown square port)
LLM = "llm"  # connection to a language model: server / API / local runner and model (purple square port)
AGENT = "agent"  # an agent: its model connection, instructions, tools and data (teal square port)


class _Marker:
    def __init__(self, name, global_name):
        self._name = name
        self._global = global_name

    def __repr__(self):
        return self._name

    def __reduce__(self):
        return self._global  # unpickled as the same object (compared with `is`; worker processes)


# Output object of a flow variable port (the variables travel in the stack).
FLOWVAR = _Marker("FlowVariablePortObject", "FLOWVAR")
# Output object / spec of a port on an inactive branch (IF Switch, ...).
INACTIVE = _Marker("InactiveBranch", "INACTIVE")


class PortObject:
    """Content of a non-table port. Must be picklable (it is saved with the workflow).

    spec() returns the lightweight object passed to downstream configure()
    (e.g. a model without the fitted estimator); columns() optionally gives a
    polars schema that dialogs of downstream nodes can offer.
    """

    port_type = ""

    def spec(self):
        return self

    def columns(self):
        return None

    def summary(self) -> dict:
        return {}

    def view_html(self) -> str | None:
        """A page of its own for port views and the hover inspection (e.g. a 3D viewer), or None. It runs in a
        sandboxed frame; __VERKNODE_BASE__ in it is the server's base URL (Package.static_url)."""
        return None


# port types of packages (register_port_type): name -> {"label", "color"}; the built-in ones have their
# own looks in the editor
PORT_TYPES: dict[str, dict] = {}


def register_port_type(name: str, label: str, color: str = "#777777", description: str = "") -> str:
    """A port type of a package (a square port of this colour): its PortObject subclasses set port_type to
    the name it returns."""
    PORT_TYPES[name] = {"label": label, "color": color, "description": description}
    return name


class ModelPortObject(PortObject):
    """A trained model: estimator plus the learning spec needed to apply it."""

    port_type = MODEL

    def __init__(self, model_type: str, estimator=None, learning_spec=None, target: str | None = None,
                 target_dtype=None, classes=None, info: dict | None = None):
        self.model_type = model_type
        self.estimator = estimator
        self.learning_spec = learning_spec  # polars Schema of the feature columns
        self.target = target
        self.target_dtype = target_dtype
        self.classes = classes
        self.info = info or {}

    def spec(self):
        return ModelPortObject(self.model_type, None, self.learning_spec, self.target, self.target_dtype,
                               self.classes, self.info)

    def columns(self):
        return self.learning_spec

    @property
    def features(self) -> list:
        return list(self.learning_spec or {})

    def summary(self) -> dict:
        out = {"Model": self.model_type}
        if self.target:
            out["Target column"] = f"{self.target} ({self.target_dtype})"
        if self.learning_spec is not None:
            out["Learning columns"] = ", ".join(self.learning_spec)
        if self.classes is not None:
            out["Classes"] = ", ".join(map(str, self.classes))
        out.update({k: v for k, v in self.info.items()})
        if self.estimator is not None:
            out["Estimator"] = repr(self.estimator)
        return out


class ImagePortObject(PortObject):
    port_type = IMAGE

    def __init__(self, data: bytes, mime: str = "image/svg+xml"):
        self.data = data
        self.mime = mime

    def spec(self):
        return ImagePortObject(b"", self.mime)

    def summary(self) -> dict:
        return {"Type": self.mime, "Size": f"{len(self.data)} bytes"}


class LLMConnectionPortObject(PortObject):
    """Where a language model is and which one: made by the LLM connector nodes, used by the LLM nodes
    (their LLM port) instead of their own server settings. Keys are not in it: the name of the
    environment variable (or ~/.verknode/llm.env setting) that holds the key is."""

    port_type = LLM

    def __init__(self, provider: str, url: str, model: str, key_env: str = "", label: str = "",
                 options: dict | None = None, headers: dict | None = None):
        self.provider = provider  # Ollama | OpenAI-compatible | Anthropic | llama.cpp (in-process)
        self.url = url
        self.model = model
        self.key_env = key_env
        self.label = label or f"{provider} · {model}"
        self.options = dict(options or {})  # (e.g. temperature: overrides the nodes' settings)
        self.headers = dict(headers or {})

    def server(self, s: dict | None = None) -> dict:
        """The server dict of nodes/llm.py (the key read now, from the environment)."""
        import re

        from jupyterlab_verknode.nodes.llm import DEFAULT_URL, saved_server, setting

        model = self.model or ((s or {}).get("model") or "").strip()
        saved = re.fullmatch(r"\$\{saved:(.+)\}", self.url or "")
        if saved:  # (a saved LLM server: its address is read now, from the node defaults - not saved here)
            srv = saved_server(saved.group(1), model)
            key_env = self.key_env or srv["key_env"]
            return {**srv, "key": setting(key_env) if key_env else "", "options": dict(self.options),
                    "headers": dict(self.headers), "label": self.label}
        # (${VERKNODE_LLM_URL}: the server's setting, read now - so a workflow keeps no private address)
        url = re.sub(r"\$\{(\w+)\}", lambda m: setting(m.group(1)) or (DEFAULT_URL if m.group(1) == "VERKNODE_LLM_URL" else ""), self.url)
        return {"provider": self.provider, "url": url.rstrip("/"), "model": model,
                "key": setting(self.key_env) if self.key_env else "", "options": dict(self.options),
                "headers": dict(self.headers), "label": self.label}

    def with_model(self, model: str, label: str = "") -> "LLMConnectionPortObject":
        return LLMConnectionPortObject(self.provider, self.url, model, self.key_env, label or "",
                                       self.options, self.headers)

    def summary(self) -> dict:
        out = {"Connection": self.label, "Provider": self.provider, "Where": self.url, "Model": self.model or "(the node's)"}
        if self.key_env:
            out["API key from"] = self.key_env
        if self.options:
            out["Options"] = ", ".join(f"{k}={v}" for k, v in self.options.items())
        return out


class AgentPortObject(PortObject):
    """An agent: a framework (verknode's tool loop, LangGraph, Deep Agents), its model connection,
    instructions (sections of a system prompt), tools, examples and data tables. Made by the agent
    nodes, run by Agent Runner, evaluated and improved by the evaluation nodes (which output changed
    copies: with_changes)."""

    port_type = AGENT

    def __init__(self, framework: str, connection, instructions: str, tools: list, tables: dict,
                 examples: str = "", settings: dict | None = None, name: str = "agent", graph: str = ""):
        self.framework = framework  # builtin | langgraph | deepagents
        self.connection = connection  # LLMConnectionPortObject or None (the defaults of the server)
        self.instructions = instructions
        self.tools = list(tools)
        self.tables = dict(tables)  # name -> polars DataFrame
        self.examples = examples
        self.settings = dict(settings or {})  # temperature, max_tokens, steps, verify, ...
        self.name = name
        self.graph = graph  # Mermaid of its graph

    def with_changes(self, **kw) -> "AgentPortObject":
        args = dict(framework=self.framework, connection=self.connection, instructions=self.instructions,
                    tools=self.tools, tables=self.tables, examples=self.examples, settings=self.settings,
                    name=self.name, graph=self.graph)
        args.update(kw)
        return AgentPortObject(**args)

    def spec(self):
        return AgentPortObject(self.framework, self.connection, self.instructions, self.tools,
                               {k: v.clear() if isinstance(v, pl.DataFrame) else v for k, v in self.tables.items()},
                               self.examples, self.settings, self.name, self.graph)

    def summary(self) -> dict:
        frame = {"builtin": "verknode tool loop", "langgraph": "LangGraph", "deepagents": "Deep Agents"}.get(self.framework, self.framework)
        out = {"Agent": self.name, "Framework": frame,
               "Model": self.connection.label if self.connection is not None else "(the server's default)",
               "Tools": ", ".join(self.tools), "Tables": ", ".join(f"{k} ({v.height} rows)" if isinstance(v, pl.DataFrame) else k
                                                                    for k, v in self.tables.items()),
               "Instructions": self.instructions[:600] + ("…" if len(self.instructions) > 600 else "")}
        if self.examples:
            out["Examples"] = self.examples[:300]
        out.update({k: v for k, v in self.settings.items() if not isinstance(v, (dict, list))})
        return out


class DBSessionPortObject(PortObject):
    """Connection to a database (SQLite file)."""

    port_type = DB_SESSION

    def __init__(self, path: str, dialect: str = "sqlite"):
        self.dialect = dialect
        self.path = path

    def connect(self):
        import sqlite3

        return sqlite3.connect(self.path)

    def tables(self) -> list:
        try:
            with self.connect() as con:
                return [r[0] for r in con.execute(
                    "SELECT name FROM sqlite_master WHERE type IN ('table', 'view') ORDER BY name")]
        except Exception:  # noqa: BLE001
            return []

    def summary(self) -> dict:
        return {"Database": self.dialect, "Path": self.path, "Tables": ", ".join(self.tables())}


class DBDataPortObject(PortObject):
    """A lazily evaluated SQL query on a database session (DB data port)."""

    port_type = DB_DATA

    def __init__(self, session: DBSessionPortObject, query: str, schema=None):
        self.session = session
        self.query = query
        self.schema = schema  # polars Schema of the query result, if known

    def columns(self):
        return self.schema

    def summary(self) -> dict:
        out = self.session.summary()
        out["SQL query"] = self.query
        return out


class InvalidSettingsError(Exception):
    """Raised by configure/validate when the node cannot be configured."""


class CanceledExecutionError(Exception):
    pass


@dataclass
class Port:
    type: str
    name: str
    description: str = ""
    optional: bool = False

    def to_json(self, index: int) -> dict:
        out = {
            "index": index,
            "type": self.type,
            "name": self.name,
            "description": self.description,
            "optional": self.optional,
            "implicit": False,
        }
        custom = PORT_TYPES.get(self.type)
        if custom is not None:
            out["color"], out["typeLabel"] = custom["color"], custom["label"]
        return out


IMPLICIT_IN = Port(FLOWVARIABLE, "Variable Inport", "Flow variables (implicit port)", optional=True)
IMPLICIT_OUT = Port(FLOWVARIABLE, "Variable Outport", "Flow variables (implicit port)", optional=True)


@dataclass
class Field:
    """A dialog setting.

    type: string | int | float | bool | enum | column | columns | code |
          records | tablecreator | varlist | multienum | variable (flow variable name) |
          widget (not in the dialog: state edited on the canvas, e.g. a Direct Input's value)
    """

    key: str
    type: str
    label: str
    default: object = None
    description: str = ""
    options: list | None = None  # enum choices
    port: int = 1  # input port providing columns for column/columns fields
    kinds: list | None = None  # restrict column fields to these column kinds
    fields: list | None = None  # sub-fields of a records field
    language: str | None = None  # code fields
    insertables: bool = False  # code field: offer $column$ / $${Svar}$$ insertion
    # string field holding a path, with a chooser in the dialog: True or "file" (a file to read), "save" (a file
    # to write, may be new), "folder", "any" (a file or a folder)
    path: bool | str = False
    extensions: list | None = None  # path fields: the file types the chooser lists first, e.g. [".csv", ".tsv"]
    path_base: str | None = None  # path fields: relative to the folder in this setting, not to the workflow
    show_if: dict | None = None  # {"key": value-or-list} visibility condition
    # sketcher fields: other settings whose change invalidates edits, {"column": "structure"|"name"}
    depends: dict | None = None
    section: str | None = None  # a heading above the first field of a section (e.g. the LLM nodes' "Model")
    options_from: dict | None = None  # enum: also these values of a records setting, {"field": ..., "key": ...}

    def to_json(self) -> dict:
        d = {
            "key": self.key,
            "type": self.type,
            "label": self.label,
            "default": self.default,
            "description": self.description,
        }
        for k in ("options", "kinds", "language", "show_if", "depends", "section", "options_from", "extensions",
                  "path_base"):
            v = getattr(self, k)
            if v is not None:
                d[k] = v
        if self.type in ("column", "columns"):
            d["port"] = self.port
        if self.fields is not None:
            d["fields"] = [f.to_json() for f in self.fields]
        if self.insertables:
            d["insertables"] = True
        if self.path:
            d["path"] = self.path
        return d

    @property
    def scalar(self) -> bool:
        return self.type in ("string", "int", "float", "bool", "enum", "column", "code")


def F(key, type, label, default=None, description="", **kw) -> Field:
    return Field(key, type, label, default, description, **kw)


class ExecContext:
    """Passed to configure/execute: flow variables, paths, logging, loops."""

    def __init__(self, stack: dict, base_dir: str, cancel_event=None, loop=None,
                 dry=False, logger=None):
        self.stack = dict(stack)
        self.pushed: dict[str, FlowVariable] = {}
        self.base_dir = base_dir
        self.loop = loop
        self.dry = dry
        self.warning: str | None = None
        self.view: str | None = None  # HTML of the node view
        self.display: dict | None = None  # JSON shown on the canvas (widget nodes)
        self.caught_error: dict | None = None  # set for Catch Errors nodes
        self.workflow_path: str | None = None  # absolute path of the .vkf file, if saved
        self._cancel = cancel_event
        self._logger = logger
        self.on_progress = None  # set by the workflow: shows set_progress on the canvas
        self.on_display = None  # set by the workflow: shows set_display on the canvas at once
        self.input_waiter = None  # set by the workflow: wait_for_input
        self.input_taker = None  # set by the workflow: received()
        self.previous_display = None  # what the node showed before this run (set by the workflow)
        self.path_mapper = None  # set by the workflow in a sandbox: real path -> its sandbox copy
        # set by the workflow: the workflow as a Workflow Script sees it (engine.workflow_edits)
        self.script_workflow = None

    # -- flow variables -------------------------------------------------
    def variables(self) -> dict:
        out = {k: v.value for k, v in self.stack.items()}
        out.update({k: v.value for k, v in self.pushed.items()})
        return out

    def variable(self, name: str):
        if name in self.pushed:
            return self.pushed[name]
        return self.stack.get(name)

    def push_variable(self, name: str, value, vtype: str | None = None):
        self.pushed[name] = make(name, value, vtype)

    # -- misc -----------------------------------------------------------
    def resolve_path(self, path: str) -> str:
        if not path:
            raise InvalidSettingsError("No file path specified")
        path = os.path.expanduser(path)
        if not os.path.isabs(path):
            path = os.path.join(self.base_dir, path)
        path = os.path.normpath(path)
        # (a test run in a sandbox: the path's copy in its temporary folder - engine.sandbox)
        return self.path_mapper(path) if self.path_mapper is not None else path

    def canceled(self) -> bool:
        """Has the user canceled the execution? (for nodes that wait on other processes)"""
        return self._cancel is not None and self._cancel.is_set()

    def check_canceled(self):
        if self.canceled():
            raise CanceledExecutionError("Execution canceled")

    def log(self, text: str, level: str = "INFO"):
        if self._logger and not self.dry:
            self._logger(level, text)

    def set_view(self, html: str):
        """Set the node view (HTML; see engine.views for helpers)."""
        if not self.dry:
            self.view = html

    def set_display(self, data: dict):
        """Set what the node shows on the canvas (JSON; nodes with a widget() method). Shown at once,
        also while the node is still running (e.g. a chat waiting for the next message)."""
        if not self.dry:
            self.display = data
            if self.on_display is not None:
                self.on_display(data)

    def received(self) -> list:
        """What the canvas sent this node before it ran (e.g. a conversation to resume), without waiting."""
        return self.input_taker() if self.input_taker is not None else []

    def wait_for_input(self):
        """Wait until the canvas sends this node something (its widget's onSend); returns it.
        Canceling the run ends the wait."""
        if self.input_waiter is None:
            raise InvalidSettingsError("This node waits for input from an open workflow editor")
        return self.input_waiter(self.canceled)

    def set_progress(self, fraction: float):
        """How far the node is (0..1), for long nodes: the canvas shows it and the ETA follows it."""
        if not self.dry and self.on_progress is not None:
            self.on_progress(min(max(float(fraction), 0.0), 1.0))

    def warn(self, text: str):
        if not self.dry:
            self.warning = text
            self.log(text, "WARN")


NODE_REGISTRY: dict[str, type] = {}
_collecting: list | None = None  # set while custom node files are imported


def register(cls):
    """Register a built-in node (inside custom node files: mark the class as a node)."""
    if _collecting is not None:
        _collecting.append(cls)
        return cls
    NODE_REGISTRY[cls.factory] = cls
    return cls


@contextlib.contextmanager
def collect_registrations():
    """Capture @register calls (custom node files) instead of registering globally."""
    global _collecting
    previous, _collecting = _collecting, []
    try:
        yield _collecting
    finally:
        _collecting = previous


class NodeModel:
    factory = ""
    name = ""
    category = ""  # "/" separated node repository path
    node_type = "Manipulator"  # Source|Sink|Manipulator|LoopStart|LoopEnd|ScopeStart|ScopeEnd|Other
    icon = ""
    short_description = ""
    description = ""
    in_ports: list[Port] = []
    out_ports: list[Port] = []
    fields: list[Field] = []
    loop_role: str | None = None  # "start" | "end"
    scope_role: str | None = None  # "try" | "catch" (error handling)
    handles_inactive = False  # receives INACTIVE inputs instead of being skipped
    # runs code or changes things outside the workflow (files not through resolve_path, servers):
    # not run in a test sandbox (engine.sandbox) unless it allows it
    sandbox_unsafe = False
    has_view = False  # execute() sets ctx.set_view(html)
    # the version of the node's settings: raise it when they change, and migrate() turns settings saved by
    # an older version into the new ones (workflows update themselves when they are opened)
    version = 1
    # nodes that close the scope this node opens (loop end, End IF, Catch ...),
    # most likely first; suggested first by the Tab quick-add while open
    closed_by: list = []

    def default_settings(self) -> dict:
        return {f.key: copy.deepcopy(f.default) for f in self.fields}

    def field(self, key: str) -> Field | None:
        for f in self.fields:
            if f.key == key:
                return f
        return None

    def validate(self, s: dict, in_specs: list):
        """Raise InvalidSettingsError if settings are incomplete."""

    def configure(self, in_specs: list, s: dict, ctx: ExecContext) -> list:
        """Return output specs (polars Schema, FLOWVAR, INACTIVE or None=unknown).

        in_specs holds one entry per explicit input port: a schema, FLOWVAR,
        INACTIVE, or None for an unconnected optional port.
        Default: execute on empty tables of the input schemas (dry run).
        Nodes with side effects or expensive execution must override.
        """
        self.validate(s, in_specs)
        inputs = []
        for spec in in_specs:
            if spec is None or spec is FLOWVAR or spec is INACTIVE or isinstance(spec, PortObject):
                inputs.append(spec)
            else:
                inputs.append(pl.DataFrame(schema=spec))
        outs = self.execute(inputs, s, ctx)
        if outs is None:
            return [None] * len(self.out_ports)
        return [spec_of(o) for o in outs]

    def execute(self, inputs: list, s: dict, ctx: ExecContext) -> list | None:
        raise NotImplementedError

    def migrate(self, settings: dict, from_version: int) -> dict:
        """Settings saved by an older version of the node (from_version < version) as this version's."""
        return settings

    @classmethod
    def describe(cls) -> dict:
        return {
            "factory": cls.factory,
            "name": cls.name,
            "category": cls.category,
            "nodeType": cls.node_type,
            "icon": cls.icon,
            "shortDescription": cls.short_description,
            "description": cls.description,
            "inPorts": [p.to_json(i + 1) for i, p in enumerate(cls.in_ports)],
            "outPorts": [p.to_json(i + 1) for i, p in enumerate(cls.out_ports)],
            "fields": [f.to_json() for f in cls.fields],
            "hasDialog": bool(cls.fields),
            "hasView": cls.has_view,
            "closedBy": list(cls.closed_by),
            # (the packages it needs beyond polars, and whether they are installed: engine/requirements.py)
            "requires": _requirements(cls),
            # (the verknode package it comes from, if any: engine/packages.py)
            "package": getattr(cls, "_verknode_package", None),
            "version": getattr(cls, "version", 1),
        }


def _requirements(cls) -> list:
    try:
        from .requirements import requirements

        return requirements(cls)
    except Exception:  # noqa: BLE001 - never in the way of describing a node
        return []


def spec_of(obj):
    if obj is None or obj is FLOWVAR:
        return FLOWVAR
    if obj is INACTIVE:
        return INACTIVE
    if isinstance(obj, pl.DataFrame):
        return obj.schema
    if isinstance(obj, PortObject):
        return obj.spec()
    return None


def require_column(s: dict, key: str, spec, label: str = "column"):
    name = s.get(key)
    if not name:
        raise InvalidSettingsError(f"No {label} selected")
    if spec is not None and spec is not FLOWVAR and name not in spec:
        raise InvalidSettingsError(f'Column "{name}" not found in input table')
    return name
